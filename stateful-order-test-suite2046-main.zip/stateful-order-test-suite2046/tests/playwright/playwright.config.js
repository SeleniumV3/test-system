module.exports = {
  timeout: 60000,
  use: { headless: true },
  testDir: './tests'
};
