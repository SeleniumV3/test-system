const { test, expect } = require('@playwright/test');

const FRONT = 'http://localhost:3001';
const API = 'http://localhost:3000';

test.describe('E2E flow on real UI', ()=>{
  test('create session, add items, checkout, handle verification and 3DS', async ({ page }) => {
    // Index page: create session
    await page.goto(FRONT + '/index.html');
    await page.click('#createSession');
    const sessionId = await page.textContent('#sessionId');
    expect(sessionId.length).toBeGreaterThan(0);

    // Add items (first cheap, then expensive to trigger verification)
    // Click first product twice
    await page.click('#products button:nth-child(1)');
    await page.waitForTimeout(200);
    await page.click('#products button:nth-child(2)');
    await page.waitForTimeout(200);

    // Proceed to checkout
    await page.click('#toCheckout');
    await page.waitForURL('**/checkout.html**');

    // Start checkout
    await page.click('#initCheckout');
    // If redirected to verification page, handle it
    if (page.url().includes('verification.html')) {
      const params = new URLSearchParams(new URL(page.url()).search);
      const sid = params.get('sessionId');
      expect(sid).toBe(sessionId);
      // provide a verification code
      await page.fill('#verificationCode', '12345');
      await page.click('#sendVerification');
      await page.waitForTimeout(800);
      // should redirect back to checkout
      await page.waitForURL('**/checkout.html**');
    }

    // Now on checkout page, if pay area visible, perform pay
    if (await page.$('#payArea') !== null) {
      const token = await page.$eval('#paymentToken', el => el.value);
      if (token) {
        // attempt to pay
        await page.click('#doPay');
        // If 3DS area appears, confirm success
        if (await page.$('#threeDSArea') !== null) {
          await page.click('#threeDSConfirm');
          await page.waitForTimeout(300);
        }
      }
    }

    // Final status should show paid or a meaningful error
    const status = await page.textContent('#status');
    expect(status.length).toBeGreaterThan(0);
  });
});
