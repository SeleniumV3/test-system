محتویات نمونه برای تست‌های Robot Framework. شامل سناریوهای شناسایی sessionId و اجرای checkout به‌صورت keyword-based.
