(function(){
  const API = 'http://localhost:3000';
  // Shared functions for frontend pages
  function $(sel){return document.querySelector(sel)}

  // Determine page
  if (document.getElementById('createSession')) {
    // index page logic
    const products = [
      { name: 'کتاب', price: 45 },
      { name: 'هدفون', price: 120 },
      { name: 'ماوس', price: 35 },
      { name: 'کیبورد', price: 90 }
    ];
    let sessionId = null;
    let cart = [];

    function renderProducts(){
      const p = $('#products');
      products.forEach((it, idx)=>{
        const b = document.createElement('button');
        b.textContent = it.name + ' - ' + it.price + ' T';
        b.onclick = ()=> addToCart(it);
        p.appendChild(b);
      });
    }

    function addToCart(item){
      if (!sessionId) { showMsg('ابتدا جلسه خرید ایجاد کنید'); return; }
      fetch(`${API}/sessions/${sessionId}/items`, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(item) })
        .then(r=>r.json())
        .then(j=>{
          if (j.error) return showMsg(JSON.stringify(j));
          cart = j.items;
          $('#total').textContent = j.total;
          renderCart();
          $('#toCheckout').disabled = false;
        })
        .catch(e=>showMsg('خطا: ' + e.message));
    }

    function renderCart(){
      const ul = $('#cart'); ul.innerHTML = '';
      cart.forEach(it=>{ const li = document.createElement('li'); li.textContent = it.name + ' - ' + it.price; ul.appendChild(li); });
    }

    function createSession(){
      fetch(`${API}/sessions`, { method:'POST' }).then(r=>r.json()).then(j=>{
        sessionId = j.sessionId;
        $('#sessionId').textContent = sessionId;
        showMsg('جلسه ایجاد شد');
      });
    }

    function toCheckout(){
      if (!sessionId) return showMsg('آیتمی موجود نیست');
      // navigate to checkout page with sessionId
      location.href = `/checkout.html?sessionId=${sessionId}`;
    }

    function showMsg(m){ $('#messages').textContent = m; }

    $('#createSession').addEventListener('click', createSession);
    $('#toCheckout').addEventListener('click', toCheckout);
    renderProducts();

  } else if (document.getElementById('initCheckout')) {
    // checkout page logic
    const params = new URLSearchParams(location.search);
    const sessionId = params.get('sessionId');
    $('#sessionId').textContent = sessionId;

    function refreshSummary(){
      fetch(`${API}/sessions/${sessionId}/status`).then(r=>r.json()).then(j=>{
        $('#summary').textContent = `وضعیت: ${j.state} - جمع: ${j.total}`;
      }).catch(e=>$('#summary').textContent = 'خطا در دریافت وضعیت');
    }

    $('#initCheckout').addEventListener('click', ()=>{
      fetch(`${API}/sessions/${sessionId}/checkout`, { method:'POST' }).then(r=>r.json()).then(j=>{
        if (j.action === 'additional_verification' || j.action === 'manual_review_required'){
          // show verification UI indirectly by navigating to verification page
          localStorage.setItem('verificationToken', j.verificationToken || '');
          location.href = `/verification.html?sessionId=${sessionId}`;
          return;
        }
        if (j.paymentToken) {
          $('#payArea').style.display = 'block';
          $('#paymentToken').value = j.paymentToken;
        }
        refreshSummary();
      });
    });

    $('#doPay').addEventListener('click', ()=>{
      const token = $('#paymentToken').value;
      const v = $('#verificationCode').value;
      fetch(`${API}/sessions/${sessionId}/pay`, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ paymentToken: token, verificationCode: v }) })
        .then(async r=>{
          const j = await r.json();
          if (j.action === '3ds_required'){
            // show 3DS UI
            $('#threeDSArea').style.display = 'block';
            $('#payArea').style.display = 'none';
            // store token
            localStorage.setItem('threeDSToken', j.threeDSToken);
          } else if (j.error) {
            $('#status').textContent = 'خطا: ' + (j.error||JSON.stringify(j));
          } else {
            $('#status').textContent = 'نتیجه: ' + (j.message||JSON.stringify(j));
          }
        });
    });

    $('#threeDSConfirm').addEventListener('click', ()=>{
      const tt = localStorage.getItem('threeDSToken');
      fetch(`${API}/sessions/${sessionId}/3ds/confirm`, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ threeDSToken: tt, result: 'success' }) })
        .then(r=>r.json()).then(j=>{ $('#status').textContent = JSON.stringify(j); });
    });
    $('#threeDSFail').addEventListener('click', ()=>{
      const tt = localStorage.getItem('threeDSToken');
      fetch(`${API}/sessions/${sessionId}/3ds/confirm`, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ threeDSToken: tt, result: 'fail' }) })
        .then(r=>r.json()).then(j=>{ $('#status').textContent = JSON.stringify(j); });
    });

    refreshSummary();

  } else if (document.getElementById('sendVerification')) {
    // verification page
    const params = new URLSearchParams(location.search);
    const sessionId = params.get('sessionId');
    $('#sendVerification').addEventListener('click', ()=>{
      const code = $('#verificationCode').value;
      fetch(`${API}/sessions/${sessionId}/pay`, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ verificationCode: code }) })
        .then(r=>r.json()).then(j=>{
          if (j.paymentToken) {
            $('#verResult').textContent = 'تأیید انجام شد، انتقال به صفحه پرداخت';
            setTimeout(()=> location.href = `/checkout.html?sessionId=${sessionId}`, 800);
          } else {
            $('#verResult').textContent = JSON.stringify(j);
          }
        });
    });
  }
})();
