// Hotel Room Booking API (Stateful) - Node.js Express
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const crypto = require('crypto');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// In-memory state (not persistent)
const rooms = {
    '101': { status: 'available', booking: null },
    '102': { status: 'available', booking: null }
};

const bookings = {}; // bookingId: { roomId, user, status: 'reserved'|'paid'|'cancelled' }

// Helper: Validate room exists
function getRoom(roomId) {
    if (!rooms[roomId]) return null;
    return rooms[roomId];
}

// 1. Reserve a room
app.post('/api/reserve', (req, res) => {
    const { roomId, user } = req.body;
    const room = getRoom(roomId);
    if (!room) return res.status(404).json({ error: 'Room not found' });
    if (room.status !== 'available') return res.status(409).json({ error: 'Room not available' });
    // Create booking
    const bookingId = crypto.randomUUID();
    bookings[bookingId] = { roomId, user, status: 'reserved' };
    room.status = 'reserved';
    room.booking = bookingId;
    return res.status(201).json({ bookingId, status: 'reserved' });
});

// 2. Pay for a reservation
app.post('/api/pay', (req, res) => {
    const { bookingId } = req.body;
    const booking = bookings[bookingId];
    if (!booking) return res.status(404).json({ error: 'Booking not found' });
    if (booking.status !== 'reserved') return res.status(409).json({ error: 'Booking not in reservable state' });
    // Simulate payment
    booking.status = 'paid';
    rooms[booking.roomId].status = 'occupied';
    return res.json({ bookingId, status: 'paid' });
});

// 3. Cancel a reservation
app.post('/api/cancel', (req, res) => {
    const { bookingId } = req.body;
    const booking = bookings[bookingId];
    if (!booking) return res.status(404).json({ error: 'Booking not found' });
    if (booking.status === 'cancelled') return res.status(409).json({ error: 'Booking already cancelled' });
    if (booking.status === 'paid') return res.status(409).json({ error: 'Cannot cancel after payment' });
    // Cancel booking
    booking.status = 'cancelled';
    rooms[booking.roomId].status = 'available';
    rooms[booking.roomId].booking = null;
    return res.json({ bookingId, status: 'cancelled' });
});

// 4. Get booking status
app.get('/api/status/:bookingId', (req, res) => {
    const booking = bookings[req.params.bookingId];
    if (!booking) return res.status(404).json({ error: 'Booking not found' });
    return res.json({ bookingId: req.params.bookingId, status: booking.status });
});

// 5. Get room state
app.get('/api/room/:roomId', (req, res) => {
    const room = getRoom(req.params.roomId);
    if (!room) return res.status(404).json({ error: 'Room not found' });
    return res.json({ roomId: req.params.roomId, status: room.status, booking: room.booking });
});

// 6. Reset state (for test only)
app.post('/api/reset', (req, res) => {
    Object.keys(rooms).forEach(roomId => {
        rooms[roomId].status = 'available';
        rooms[roomId].booking = null;
    });
    Object.keys(bookings).forEach(bid => { delete bookings[bid]; });
    return res.json({ ok: true });
});

app.listen(3000, () => {
    console.log('Hotel Booking API running on port 3000');
});
