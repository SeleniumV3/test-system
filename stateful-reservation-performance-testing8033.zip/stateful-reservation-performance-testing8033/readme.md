# سناریو و چالش‌های تست Performance و Scalability برای سرویس رزرو آنلاین

## مقدمه
در این مسأله، باید تست‌های Performance و Scalability را برای یک سرویس رزرو آنلاین با جریان‌های کاری وابسته به State و چندمسیره طراحی و اجرا نمایید. هدف، ارزیابی رفتار سیستم تحت بار و شرایط استرس واقعی با استفاده از Apache JMeter است. لازم است سناریوهای تست به گونه‌ای طراحی شوند که وابستگی State، ترتیب درخواست‌ها و مسیرهای موفق و ناموفق را پوشش دهند و تحلیل عمیقی از نتایج ارائه گردد.

## ابزارها و الزامات
- ابزار الزامی برای تست Performance/Scalability و Non-Functional: **Apache JMeter**
- اجرای سرویس Node.js با فایل `app.js` (پورت 3000)
- اجرای همزمان Frontend (در صورت وجود) روی پورت 3001
- اجرای تست‌ها فقط بر روی سرویس ارائه‌شده؛ ایجاد سرویس جدید مجاز نیست
- خروجی تست‌ها باید فقط در فولدر `tests/` و مسیرهای تعیین‌شده قرار گیرد

## نحوه اجرا
برای اجرای سرویس و (در صورت وجود) UI، فایل `start.bat` را اجرا کنید. سرویس Node.js روی پورت 3000 و Frontend روی پورت 3001 اجرا می‌شود.

## ساختار خروجی مورد انتظار

tests/
─ jmeter/
   ─ test-plan.jmx
   ─ results.jtl | report/
─ Report.md


## چالش‌ها
### 1. Performance / Scalability Testing – ارزیابی پاسخ سیستم تحت بار – Apache JMeter
طراحی تست بار برای ۱۰ تا ۱۰۰ کاربر هم‌زمان و ثبت زمان پاسخ میانگین و خطاها (p95/p99). سناریو باید شامل توالی درخواست‌های وابسته به State و مسیرهای کاری مختلف باشد. تحلیل Bottleneckها و خطاها الزامی است.

### 2. Non-Functional Testing (Load / Stress) – ارزیابی پایداری در شرایط فشار – Apache JMeter
اجرای تست استرس با حداقل ۱۰۰۰ درخواست متوالی و بررسی عدم بروز خطای 500 یا memory leak. تمرکز بر تحلیل رفتار سیستم تحت فشار، شناسایی نشانه‌های ناپایداری و مستندسازی رفتار غیرعادی.

## کاتالوگ سرویس‌ها (API Contract)

| Method | Path                 | هدف Endpoint              | پیش‌نیاز State/Sequence          | Request (Headers/Body/Params)                       | Responseهای ممکن (کد/Schema)                                                                                                 | خطاهای معنادار (کد/شرط)                | نمونه درخواست/پاسخ (کلی)                                                |
|--------|----------------------|---------------------------|-----------------------------------|-----------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------|-------------------------------------------------------------------------|
| POST   | /reserve/start       | شروع فرآیند رزرو جدید     | -                                 | { userId }                                          | 201 { reservationId, status: 'started' }                                                                                      | 400 (ورودی نامعتبر)                     | { userId: "u1" } → { reservationId: "r1", status: "started" }        |
| POST   | /reserve/select     | انتخاب آیتم برای رزرو     | رزرو باید با start فعال شده باشد | { reservationId, itemId }                            | 200 { reservationId, items: [...], status: 'selecting' }                                                                      | 404 (رزرو ناموجود)                      | { reservationId: "r1", itemId: "i1" } → { ... }                       |
| POST   | /reserve/confirm    | تایید رزرو                | حداقل یک آیتم انتخاب شده باشد     | { reservationId }                                   | 200 { reservationId, status: 'confirmed', summary: ... }                                                                      | 409 (بدون آیتم)                         | { reservationId: "r1" } → { ... }                                      |
| POST   | /reserve/cancel     | لغو رزرو                  | رزرو باید در حالت started/select | { reservationId }                                   | 200 { reservationId, status: 'cancelled' }                                                                                    | 404 (رزرو ناموجود)                      | { reservationId: "r1" } → { ... }                                      |
| GET    | /reserve/status     | دریافت وضعیت رزرو         | reservationId معتبر               | query: reservationId                                | 200 { reservationId, status, items: [...], ... }                                                                              | 404 (رزرو ناموجود)                      | /reserve/status?reservationId=r1 → { ... }                               |

### توضیحات تکمیلی:
- هر رزرو فقط با توالی: start → select (n بار) → confirm/cancel معتبر است.
- ارسال confirm بدون select → خطای 409
- ارسال select قبل از start → خطای 404
- ارسال cancel پس از confirm → خطای 409
- هر reservationId فقط یک بار قابل تایید یا لغو است؛ درخواست مجدد → خطای 409
- State داخلی سرویس: لیست رزروها، وضعیت فعلی هر رزرو، آیتم‌های انتخاب‌شده

### نمونه درخواست/پاسخ (شمای کلی)

**شروع رزرو:**
POST /reserve/start
Body: { "userId": "u1" }
Response: { "reservationId": "r1", "status": "started" }

**انتخاب آیتم:**
POST /reserve/select
Body: { "reservationId": "r1", "itemId": "i1" }
Response: { "reservationId": "r1", "items": ["i1"], "status": "selecting" }

**تایید رزرو:**
POST /reserve/confirm
Body: { "reservationId": "r1" }
Response: { "reservationId": "r1", "status": "confirmed", ... }

**لغو رزرو:**
POST /reserve/cancel
Body: { "reservationId": "r1" }
Response: { "reservationId": "r1", "status": "cancelled" }

**دریافت وضعیت:**
GET /reserve/status?reservationId=r1
Response: { "reservationId": "r1", "status": "confirmed", "items": ["i1"], ... }

## مستندات اولیه و راهنما (hint)
- سناریوهای تست باید شامل توالی‌های معتبر و نامعتبر (مثلاً تأیید بدون انتخاب آیتم، انتخاب قبل از شروع، لغو پس از تایید و ...) باشد.
- برای تست Performance، جریان‌های کاری مختلف (رزرو موفق، رزرو لغو شده، تلاش برای تایید نامعتبر و ...) را با بارهای متفاوت شبیه‌سازی کنید.
- در تست استرس، رفتار سیستم را در مواجهه با درخواست‌های متوالی، وضعیت State داخلی و نرخ بروز خطاها تحلیل نمایید.
- صرفاً به داده‌های خام JMeter یا زمان پاسخ متوسط اکتفا نکنید؛ تحلیل عمیق Bottleneckها و نقاط ضعف عملکردی الزامی است.
- نتایج تست را با جداول، نمودار و تحلیل روند در Report.md مستند کنید.
- تست‌ها باید نشان دهند که API واقعاً Stateful است و رفتار آن فقط Echo یا Stateless نیست.
