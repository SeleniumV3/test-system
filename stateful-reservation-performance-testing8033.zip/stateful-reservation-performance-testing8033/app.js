// سرویس رزرو آنلاین با State وابسته و سناریوهای چندمسیره
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const crypto = require('crypto');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const reservations = {}; // state داخلی
const ITEMS = ['i1', 'i2', 'i3', 'i4'];

function generateId() {
  return crypto.randomBytes(8).toString('hex');
}

// شروع رزرو جدید
app.post('/reserve/start', (req, res) => {
  const { userId } = req.body;
  if (!userId) return res.status(400).json({ error: 'userId required' });
  const reservationId = generateId();
  reservations[reservationId] = {
    userId,
    status: 'started',
    items: [],
    createdAt: Date.now()
  };
  res.status(201).json({ reservationId, status: 'started' });
});

// انتخاب آیتم برای رزرو
app.post('/reserve/select', (req, res) => {
  const { reservationId, itemId } = req.body;
  if (!reservationId || !itemId) return res.status(400).json({ error: 'reservationId and itemId required' });
  const r = reservations[reservationId];
  if (!r) return res.status(404).json({ error: 'reservation not found' });
  if (r.status !== 'started' && r.status !== 'selecting') return res.status(409).json({ error: 'cannot select item in current state' });
  if (!ITEMS.includes(itemId)) return res.status(400).json({ error: 'invalid itemId' });
  if (!r.items.includes(itemId)) r.items.push(itemId);
  r.status = 'selecting';
  res.json({ reservationId, items: r.items, status: r.status });
});

// تایید رزرو
app.post('/reserve/confirm', (req, res) => {
  const { reservationId } = req.body;
  if (!reservationId) return res.status(400).json({ error: 'reservationId required' });
  const r = reservations[reservationId];
  if (!r) return res.status(404).json({ error: 'reservation not found' });
  if (r.status !== 'started' && r.status !== 'selecting') return res.status(409).json({ error: 'cannot confirm in current state' });
  if (!r.items || r.items.length === 0) return res.status(409).json({ error: 'no items selected' });
  r.status = 'confirmed';
  r.confirmedAt = Date.now();
  res.json({ reservationId, status: r.status, summary: { userId: r.userId, items: r.items, confirmedAt: r.confirmedAt } });
});

// لغو رزرو
app.post('/reserve/cancel', (req, res) => {
  const { reservationId } = req.body;
  if (!reservationId) return res.status(400).json({ error: 'reservationId required' });
  const r = reservations[reservationId];
  if (!r) return res.status(404).json({ error: 'reservation not found' });
  if (r.status === 'confirmed' || r.status === 'cancelled') return res.status(409).json({ error: 'cannot cancel in current state' });
  r.status = 'cancelled';
  r.cancelledAt = Date.now();
  res.json({ reservationId, status: r.status });
});

// دریافت وضعیت رزرو
app.get('/reserve/status', (req, res) => {
  const { reservationId } = req.query;
  const r = reservations[reservationId];
  if (!r) return res.status(404).json({ error: 'reservation not found' });
  res.json({ reservationId, status: r.status, items: r.items, userId: r.userId, createdAt: r.createdAt, confirmedAt: r.confirmedAt, cancelledAt: r.cancelledAt });
});

app.listen(3000, () => {
  console.log('Reservation service running on port 3000');
});
