// --- app.js ---
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const crypto = require('crypto');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// State: users, credits, orders
const users = {
    'alice': { credit: 100, orders: [] },
    'bob': { credit: 50, orders: [] },
};
const orders = {};

// Helper: generate orderId
function genId() {
    return crypto.randomBytes(4).toString('hex');
}

// POST /api/login
app.post('/api/login', (req, res) => {
    const { username } = req.body;
    if (!users[username]) return res.status(404).json({ error: 'User not found' });
    // Fake token (username as token)
    res.json({ token: username });
});

// POST /api/order
// Body: { token, item, amount }
// State: user must exist, have enough credit, item not empty
app.post('/api/order', (req, res) => {
    const { token, item, amount } = req.body;
    if (!users[token]) return res.status(401).json({ error: 'Invalid token' });
    if (!item || typeof amount !== 'number' || amount <= 0) return res.status(400).json({ error: 'Invalid order data' });
    if (users[token].credit < amount) return res.status(403).json({ error: 'Insufficient credit' });
    const orderId = genId();
    orders[orderId] = { user: token, item, amount, status: 'pending' };
    users[token].credit -= amount;
    users[token].orders.push(orderId);
    res.status(201).json({ orderId, newCredit: users[token].credit });
});

// POST /api/order/cancel
// Body: { token, orderId }
// State: user must own order, order must be pending
app.post('/api/order/cancel', (req, res) => {
    const { token, orderId } = req.body;
    if (!users[token]) return res.status(401).json({ error: 'Invalid token' });
    if (!orders[orderId] || orders[orderId].user !== token) return res.status(404).json({ error: 'Order not found' });
    if (orders[orderId].status !== 'pending') return res.status(409).json({ error: 'Order cannot be cancelled' });
    orders[orderId].status = 'cancelled';
    users[token].credit += orders[orderId].amount;
    res.json({ orderId, status: 'cancelled', newCredit: users[token].credit });
});

// GET /api/orders
// Query: token
// State: user must exist
app.get('/api/orders', (req, res) => {
    const token = req.query.token;
    if (!users[token]) return res.status(401).json({ error: 'Invalid token' });
    const userOrders = users[token].orders.map(id => ({ orderId: id, ...orders[id] }));
    res.json({ orders: userOrders });
});

// POST /api/order/complete
// Body: { token, orderId }
// State: user must own order, order must be pending
app.post('/api/order/complete', (req, res) => {
    const { token, orderId } = req.body;
    if (!users[token]) return res.status(401).json({ error: 'Invalid token' });
    if (!orders[orderId] || orders[orderId].user !== token) return res.status(404).json({ error: 'Order not found' });
    if (orders[orderId].status !== 'pending') return res.status(409).json({ error: 'Order cannot be completed' });
    orders[orderId].status = 'completed';
    res.json({ orderId, status: 'completed' });
});

app.listen(3000, () => console.log('API server running on :3000'));
