// frontend/app.js
const apiBase = 'http://localhost:3000/api/leave';
let currentRequestId = null;

const form = document.getElementById('leave-form');
const formMsg = document.getElementById('form-msg');
const mainView = document.getElementById('main-view');
const detailsView = document.getElementById('details-view');
const detailsDiv = document.getElementById('leave-details');
const approveBtn = document.getElementById('approve-btn');
const rejectBtn = document.getElementById('reject-btn');
const cancelBtn = document.getElementById('cancel-btn');
const actionMsg = document.getElementById('action-msg');
const backBtn = document.getElementById('back-btn');

form.onsubmit = async (e) => {
    e.preventDefault();
    formMsg.textContent = '';
    const data = {
        employeeId: document.getElementById('employeeId').value,
        fromDate: document.getElementById('fromDate').value,
        toDate: document.getElementById('toDate').value,
        reason: document.getElementById('reason').value
    };
    try {
        const resp = await fetch(apiBase + '/request', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        if (!resp.ok) {
            const err = await resp.json();
            formMsg.textContent = err.error || 'خطا در ثبت درخواست';
            return;
        }
        const result = await resp.json();
        currentRequestId = result.requestId;
        showDetails(currentRequestId);
    } catch (e) {
        formMsg.textContent = 'خطا در ارتباط با سرور';
    }
};

async function showDetails(reqId) {
    mainView.style.display = 'none';
    detailsView.style.display = 'block';
    actionMsg.textContent = '';
    try {
        const resp = await fetch(apiBase + '/' + reqId);
        const data = await resp.json();
        detailsDiv.innerHTML = `<b>کد درخواست:</b> ${reqId}<br/><b>کد پرسنلی:</b> ${data.employeeId}<br/><b>از:</b> ${data.fromDate}<br/><b>تا:</b> ${data.toDate}<br/><b>دلیل:</b> ${data.reason}<br/><b>وضعیت فعلی:</b> <span id='state-span'>${data.state}</span>`;
        updateActions(data.state);
    } catch (e) {
        detailsDiv.textContent = 'خطا در دریافت اطلاعات درخواست';
    }
}

function updateActions(state) {
    approveBtn.style.display = state === 'PENDING' ? 'inline-block' : 'none';
    rejectBtn.style.display = state === 'PENDING' ? 'inline-block' : 'none';
    cancelBtn.style.display = state === 'PENDING' ? 'inline-block' : 'none';
}

approveBtn.onclick = () => handleAction('approve');
rejectBtn.onclick = () => handleAction('reject');
cancelBtn.onclick = () => handleAction('cancel');

async function handleAction(action) {
    actionMsg.textContent = '';
    try {
        const resp = await fetch(`${apiBase}/${currentRequestId}/${action}`, { method: 'POST' });
        if (!resp.ok) {
            const err = await resp.json();
            actionMsg.textContent = err.error || 'خطا در انجام عملیات';
        } else {
            const data = await resp.json();
            document.getElementById('state-span').textContent = data.state;
            updateActions(data.state);
            actionMsg.textContent = 'عملیات با موفقیت انجام شد';
        }
    } catch (e) {
        actionMsg.textContent = 'خطا در ارتباط با سرور';
    }
}

backBtn.onclick = () => {
    detailsView.style.display = 'none';
    mainView.style.display = 'block';
    form.reset();
    formMsg.textContent = '';
};
