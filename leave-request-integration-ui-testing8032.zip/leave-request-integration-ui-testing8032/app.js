// app.js
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const crypto = require('crypto');

const app = express();
app.use(bodyParser.json());
app.use(cors());

const leaveRequests = {};

function getState(reqId) {
    if (!leaveRequests[reqId]) return null;
    return leaveRequests[reqId].state;
}

app.post('/api/leave/request', (req, res) => {
    const { employeeId, fromDate, toDate, reason } = req.body;
    if (!employeeId || !fromDate || !toDate || !reason) {
        return res.status(400).json({ error: 'Missing required fields.' });
    }
    const id = crypto.randomUUID();
    leaveRequests[id] = {
        employeeId,
        fromDate,
        toDate,
        reason,
        state: 'PENDING',
        history: [ { state: 'PENDING', ts: Date.now() } ]
    };
    res.status(201).json({ requestId: id, state: 'PENDING' });
});

app.get('/api/leave/:id', (req, res) => {
    const reqId = req.params.id;
    if (!leaveRequests[reqId]) {
        return res.status(404).json({ error: 'Request not found.' });
    }
    res.json({ ...leaveRequests[reqId], requestId: reqId });
});

app.post('/api/leave/:id/approve', (req, res) => {
    const reqId = req.params.id;
    if (!leaveRequests[reqId]) {
        return res.status(404).json({ error: 'Request not found.' });
    }
    if (leaveRequests[reqId].state !== 'PENDING') {
        return res.status(409).json({ error: 'Request not in PENDING state.' });
    }
    leaveRequests[reqId].state = 'APPROVED';
    leaveRequests[reqId].history.push({ state: 'APPROVED', ts: Date.now() });
    res.json({ requestId: reqId, state: 'APPROVED' });
});

app.post('/api/leave/:id/reject', (req, res) => {
    const reqId = req.params.id;
    if (!leaveRequests[reqId]) {
        return res.status(404).json({ error: 'Request not found.' });
    }
    if (leaveRequests[reqId].state !== 'PENDING') {
        return res.status(409).json({ error: 'Request not in PENDING state.' });
    }
    leaveRequests[reqId].state = 'REJECTED';
    leaveRequests[reqId].history.push({ state: 'REJECTED', ts: Date.now() });
    res.json({ requestId: reqId, state: 'REJECTED' });
});

app.post('/api/leave/:id/cancel', (req, res) => {
    const reqId = req.params.id;
    if (!leaveRequests[reqId]) {
        return res.status(404).json({ error: 'Request not found.' });
    }
    if (leaveRequests[reqId].state !== 'PENDING') {
        return res.status(409).json({ error: 'Only pending requests can be cancelled.' });
    }
    leaveRequests[reqId].state = 'CANCELLED';
    leaveRequests[reqId].history.push({ state: 'CANCELLED', ts: Date.now() });
    res.json({ requestId: reqId, state: 'CANCELLED' });
});

app.get('/api/leave/:id/history', (req, res) => {
    const reqId = req.params.id;
    if (!leaveRequests[reqId]) {
        return res.status(404).json({ error: 'Request not found.' });
    }
    res.json({ requestId: reqId, history: leaveRequests[reqId].history });
});

app.listen(3000, () => {
    console.log('Leave API running on port 3000');
});
