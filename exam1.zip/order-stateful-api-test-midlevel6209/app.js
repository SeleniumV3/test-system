// app.js
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const crypto = require('crypto');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// State: Orders + Locked IDs
let orders = {};
let lockedOrders = new Set();

// Auth Middleware
function auth(req, res, next) {
    const token = req.headers['authorization'];
    if (!token || token !== 'Bearer test-token') {
        return res.status(401).json({error: 'Unauthorized'});
    }
    next();
}

// Create Order
app.post('/orders', auth, (req, res) => {
    const { customer, items } = req.body;
    if (!customer || !Array.isArray(items) || items.length === 0) {
        return res.status(400).json({error: 'Invalid input'});
    }
    const id = crypto.randomBytes(8).toString('hex');
    orders[id] = {
        id,
        customer,
        items,
        status: 'pending',
        createdAt: Date.now()
    };
    res.status(201).json({id});
});

// Get Order
app.get('/orders/:id', auth, (req, res) => {
    const order = orders[req.params.id];
    if (!order) {
        return res.status(404).json({error: 'Order not found'});
    }
    res.json(order);
});

// Update Order (only if not locked)
app.put('/orders/:id', auth, (req, res) => {
    const order = orders[req.params.id];
    if (!order) {
        return res.status(404).json({error: 'Order not found'});
    }
    if (lockedOrders.has(req.params.id)) {
        return res.status(409).json({error: 'Order is locked'});
    }
    const { customer, items, status } = req.body;
    if (customer && typeof customer !== 'string') {
        return res.status(400).json({error: 'Invalid customer'});
    }
    if (items && (!Array.isArray(items) || items.length === 0)) {
        return res.status(400).json({error: 'Invalid items'});
    }
    if (status && !['pending', 'confirmed', 'shipped', 'cancelled'].includes(status)) {
        return res.status(400).json({error: 'Invalid status'});
    }
    if (status === 'confirmed') {
        lockedOrders.add(req.params.id);
    }
    orders[req.params.id] = {
        ...order,
        customer: customer || order.customer,
        items: items || order.items,
        status: status || order.status
    };
    res.json({message: 'Order updated'});
});

// Delete Order (only if not locked)
app.delete('/orders/:id', auth, (req, res) => {
    const order = orders[req.params.id];
    if (!order) {
        return res.status(404).json({error: 'Order not found'});
    }
    if (lockedOrders.has(req.params.id)) {
        return res.status(409).json({error: 'Order is locked'});
    }
    delete orders[req.params.id];
    res.json({message: 'Order deleted'});
});

// List Orders
app.get('/orders', auth, (req, res) => {
    res.json(Object.values(orders));
});

app.listen(3000, () => {
    console.log('Order API listening on port 3000');
});
